# TypeScript Code Style

- Use 2 spaces for indentation
- Use single quotes for strings
- Add trailing commas in multiline objects
- Use camelCase for variables and functions
- Use PascalCase for classes and interfaces